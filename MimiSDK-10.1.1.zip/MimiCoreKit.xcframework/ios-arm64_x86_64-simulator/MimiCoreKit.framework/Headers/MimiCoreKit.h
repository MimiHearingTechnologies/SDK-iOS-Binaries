//
//  MimiCoreKit.h
//  MimiCoreKit
//
//  Created by Merrick Sapsford on 20/01/2019.
//  Copyright © 2019 Mimi Hearing Technologies GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MimiCoreKit.
FOUNDATION_EXPORT double MimiCoreKitVersionNumber;

//! Project version string for MimiCoreKit.
FOUNDATION_EXPORT const unsigned char MimiCoreKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MimiCoreKit/PublicHeader.h>


