//
//  MimiTestKit.h
//  MimiTestKit
//
//  Created by Merrick Sapsford on 21/08/2018.
//  Copyright © 2018 Mimi Hearing Technologies GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MimiTestKit.
FOUNDATION_EXPORT double MimiTestKitVersionNumber;

//! Project version string for MimiTestKit.
FOUNDATION_EXPORT const unsigned char MimiTestKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MimiTestKit/PublicHeader.h>


