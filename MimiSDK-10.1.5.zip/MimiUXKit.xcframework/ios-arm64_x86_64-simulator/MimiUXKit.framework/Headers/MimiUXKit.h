//
//  MimiUXKit.h
//  MimiUXKit
//
//  Created by Merrick Sapsford on 10/08/2018.
//  Copyright © 2018 Mimi Hearing Technologies GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MimiUX.
FOUNDATION_EXPORT double MimiUXKitVersionNumber;

//! Project version string for MimiUX.
FOUNDATION_EXPORT const unsigned char MimiUXKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MimiUXKitPublicHeader.h>


