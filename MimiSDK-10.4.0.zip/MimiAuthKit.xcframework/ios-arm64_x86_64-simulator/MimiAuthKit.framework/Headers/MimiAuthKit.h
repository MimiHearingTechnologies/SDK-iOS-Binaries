//
//  MimiAuthKit.h
//  MimiAuthKit
//
//  Created by Merrick Sapsford on 22/01/2019.
//  Copyright © 2019 Mimi Hearing Technologies GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MimiAuthKit.
FOUNDATION_EXPORT double MimiAuthKitVersionNumber;

//! Project version string for MimiAuthKit.
FOUNDATION_EXPORT const unsigned char MimiAuthKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MimiAuthKit/PublicHeader.h>


