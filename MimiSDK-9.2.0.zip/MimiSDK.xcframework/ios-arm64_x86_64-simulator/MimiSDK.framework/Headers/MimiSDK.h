//
//  MimiSDK.h
//  MimiSDK
//
//  Created by Merrick Sapsford on 19/02/2019.
//  Copyright © 2019 Mimi Hearing Technologies GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MimiSDK.
FOUNDATION_EXPORT double MimiSDKVersionNumber;

//! Project version string for MimiSDK.
FOUNDATION_EXPORT const unsigned char MimiSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MimiSDK/PublicHeader.h>


